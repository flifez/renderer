//
// Created by flif3 on 8/2/2023.
//

#include "Light.h"

namespace Raytracer {
    Vec3 Light::getDirection(const Vec3 &point) const {
        return {};
    }

    Vec3 Light::getIntensity(const Vec3 &point) const {
        return {};
    }

    Vec3 Light::getColor() const {
        return {};
    }
}