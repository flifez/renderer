//
// Created by flif3 on 8/2/2023.
//

#include "SunLight.h"

namespace Raytracer {
} // Raytracer