//
// Created by flif3 on 8/2/2023.
//

#include "AreaLight.h"

namespace Raytracer {
} // Raytracer