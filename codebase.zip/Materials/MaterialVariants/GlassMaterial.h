//
// Created by flif3 on 8/2/2023.
//

#pragma once

namespace Raytracer {

    class GlassMaterial {
    public:

    private:

    };

} // Raytracer
