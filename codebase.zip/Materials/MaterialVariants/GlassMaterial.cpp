//
// Created by flif3 on 8/2/2023.
//

#include "GlassMaterial.h"

namespace Raytracer {
} // Raytracer